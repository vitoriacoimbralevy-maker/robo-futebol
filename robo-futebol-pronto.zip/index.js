
import express from "express";
import bodyParser from "body-parser";
import fetch from "node-fetch";

const app = express();
app.use(bodyParser.json());

const PORT = process.env.PORT || 10000;
const VERIFY_TOKEN = process.env.VERIFY_TOKEN;
const ACCESS_TOKEN = process.env.META_ACCESS_TOKEN;
const PHONE_NUMBER_ID = process.env.META_PHONE_NUMBER_ID;

app.get("/", (req, res) => {
  res.send("Robô de Futebol ativo!");
});

// Webhook verify (Meta)
app.get("/webhook", (req, res) => {
  const mode = req.query["hub.mode"];
  const token = req.query["hub.verify_token"];
  const challenge = req.query["hub.challenge"];

  if (mode && token === VERIFY_TOKEN) {
    res.status(200).send(challenge);
  } else {
    res.sendStatus(403);
  }
});

// Receber mensagens do WhatsApp
app.post("/webhook", async (req, res) => {
  console.log("Recebido:", JSON.stringify(req.body, null, 2));
  res.sendStatus(200);

  try {
    const msg = req.body.entry?.[0].changes?.[0].value.messages?.[0];
    if (!msg) return;

    const from = msg.from;
    const text = msg.text?.body || "";

    await sendMessage(from, "Robô ativado! Em breve você receberá sinais.");
  } catch (e) {
    console.error("Erro:", e);
  }
});

// Enviar mensagem
async function sendMessage(to, message) {
  await fetch(
    `https://graph.facebook.com/v18.0/${PHONE_NUMBER_ID}/messages`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${ACCESS_TOKEN}`,
      },
      body: JSON.stringify({
        messaging_product: "whatsapp",
        to,
        text: { body: message },
      }),
    }
  );
}

app.listen(PORT, () =>
  console.log(`Servidor rodando na porta ${PORT}`)
);
